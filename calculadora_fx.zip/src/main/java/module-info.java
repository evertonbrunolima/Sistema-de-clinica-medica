module com.mycompany.testefx2 {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.mycompany.testefx2 to javafx.fxml;
    exports com.mycompany.testefx2;
}
