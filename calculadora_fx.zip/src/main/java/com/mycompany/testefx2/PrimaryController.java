package com.mycompany.testefx2;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import calculadora.*;
import javafx.scene.control.Alert;
import javafx.scene.control.TextArea;

public class PrimaryController implements Initializable {

    @FXML
    ChoiceBox<String> Cbopcoes;
    @FXML
    TextField inputn1;
    @FXML
    TextField inputn2;
    @FXML
    TextArea resultado;
    calculadora calc = new calculadora();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        Cbopcoes.getItems().addAll("Soma", "Substração", "Multiplicação", "Divisão");
        Cbopcoes.setValue("Soma");
        resultado.setEditable(false);
    }

    @FXML
    public void calcular() {
        try {
            int op = Cbopcoes.getSelectionModel().getSelectedIndex();
            float n1 = Float.parseFloat(inputn1.getText());
            float n2 = Float.parseFloat(inputn2.getText());
            if (n2 == 0 && op == 3){
                Alert_erro("Erro no calculo", "Impossível divisão por 0");
                return ;
            }
            resultado.setText(Float.toString(calc.calcular(op + 1, n1, n2)));
            System.out.println(calc.calcular(op + 1, n1, n2));
        } catch (NumberFormatException Ex) {
            Alert_erro("Informação conflitantes", "Números informados incorretamentes!");
            resultado.setText("");
        } catch (Exception e) {
            Alert_erro("Erro no calculo", "OPS... ocorreu um erro no calculo");
            resultado.setText("");
        }

    }

    private void Alert_erro(String titulo, String texto) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Erro");
        alert.setHeaderText(titulo);
        alert.setContentText(texto);
        alert.showAndWait();
    }
    
    public void Mostrar_infor(){
        calcular(); 
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Erro");
        alert.setHeaderText("informações do calculo");
        String n1 = inputn1.getText(); 
        String n2 = inputn2.getText();
        String op = Cbopcoes.getValue(); 
        String resul = resultado.getText(); 
        String texto = "Numero 1: "+n1+"\nOpção: "+op+"\nNumero 2: "+n2+"\nResultado: "+resul; 
        alert.setContentText(texto);
        alert.showAndWait();
    }

}
