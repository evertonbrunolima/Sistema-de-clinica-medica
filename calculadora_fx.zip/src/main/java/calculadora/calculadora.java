/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calculadora;

/**
 *
 * @author evert
 */
public class calculadora {
 private float num1; 
    private float num2; 
    public void setnum1(float n1){
        this.num1 = n1;
    }
    public void setnum2(float n2){
        this.num2 = n2;
    }
    public float getnum1(){
        return this.num1;
    }
    public float getnum2(){
        return this.num2;
    }
    public float calcular (int opcao){ 
    if (opcao == 1){
            return this.soma();      
        }
        if (opcao == 2){
            return this.subtracao(); 
        }
        if (opcao == 3){
            return this.multiplicacao();
        }
        return this.divisao();
    }
    public float calcular(int opcao, float n1, float n2){
        if (opcao == 1){
            return this.soma(n1,n2);      
        }
        if (opcao == 2){
            return this.subtracao(n1,n2); 
        }
        if (opcao == 3){
            return this.multiplicacao(n1,n2);
        }
        return this.divisao(n1,n2);
        
    }
    private float subtracao(){
        return this.num1-this.num2;
    } 
    private float subtracao(float n1, float n2){
        return n1-n2; 
    }
    private float multiplicacao(){
        return this.num1*this.num2;
    } 
    private float multiplicacao (float n1, float n2){
        return n1*n2; 
    }
    private float soma(){
        return this.num1+this.num2;
    } 
    private float soma (float n1, float n2){
        return n1+n2; 
    }
    private float divisao(){
        return this.num1/this.num2;
    } 
    private float divisao(float n1, float n2){
        return n1/n2; 
    }
}

